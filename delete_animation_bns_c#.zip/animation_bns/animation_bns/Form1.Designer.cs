﻿
namespace animation_bns
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DeleteButton = new System.Windows.Forms.Button();
            this.RestoreButton = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.RecoveryPath = new System.Windows.Forms.TextBox();
            this.GamePath = new System.Windows.Forms.TextBox();
            this.FileGameButton = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // DeleteButton
            // 
            this.DeleteButton.Location = new System.Drawing.Point(6, 219);
            this.DeleteButton.Name = "DeleteButton";
            this.DeleteButton.Size = new System.Drawing.Size(214, 24);
            this.DeleteButton.TabIndex = 0;
            this.DeleteButton.Text = "Удалить анимации";
            this.DeleteButton.UseVisualStyleBackColor = true;
            this.DeleteButton.Click += new System.EventHandler(this.button1_Click);
            // 
            // RestoreButton
            // 
            this.RestoreButton.Location = new System.Drawing.Point(264, 219);
            this.RestoreButton.Name = "RestoreButton";
            this.RestoreButton.Size = new System.Drawing.Size(214, 24);
            this.RestoreButton.TabIndex = 2;
            this.RestoreButton.Text = "Восстановить анимации";
            this.RestoreButton.UseVisualStyleBackColor = true;
            this.RestoreButton.Click += new System.EventHandler(this.RestoreButton_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.RecoveryPath);
            this.groupBox1.Controls.Add(this.GamePath);
            this.groupBox1.Controls.Add(this.FileGameButton);
            this.groupBox1.Controls.Add(this.RestoreButton);
            this.groupBox1.Controls.Add(this.DeleteButton);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(484, 249);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Анимации BNS";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(115, 167);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(277, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "Путь к резервной копии анимаций";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_2);
            // 
            // RecoveryPath
            // 
            this.RecoveryPath.Location = new System.Drawing.Point(0, 138);
            this.RecoveryPath.Multiline = true;
            this.RecoveryPath.Name = "RecoveryPath";
            this.RecoveryPath.Size = new System.Drawing.Size(472, 23);
            this.RecoveryPath.TabIndex = 5;
            this.RecoveryPath.TextChanged += new System.EventHandler(this.RecoveryPath_TextChanged);
            // 
            // GamePath
            // 
            this.GamePath.Location = new System.Drawing.Point(6, 48);
            this.GamePath.Multiline = true;
            this.GamePath.Name = "GamePath";
            this.GamePath.Size = new System.Drawing.Size(472, 23);
            this.GamePath.TabIndex = 4;
            this.GamePath.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.GamePath_KeyPress);
            // 
            // FileGameButton
            // 
            this.FileGameButton.Location = new System.Drawing.Point(115, 77);
            this.FileGameButton.Name = "FileGameButton";
            this.FileGameButton.Size = new System.Drawing.Size(277, 23);
            this.FileGameButton.TabIndex = 3;
            this.FileGameButton.Text = "Путь к анимациям в игре";
            this.FileGameButton.UseVisualStyleBackColor = true;
            this.FileGameButton.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(508, 264);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button DeleteButton;
        private System.Windows.Forms.Button RestoreButton;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button FileGameButton;
        private System.Windows.Forms.TextBox GamePath;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox RecoveryPath;
    }
}

