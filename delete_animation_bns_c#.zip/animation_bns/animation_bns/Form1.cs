﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace animation_bns
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e) // Удаление анимаций
        {
            string[] q = Directory.GetFiles(GamePath.Text,
                "*00007911.upk");
            Array.ForEach(q, File.Delete);
            //=====================================================
            string[] w = Directory.GetFiles(GamePath.Text,
                "*00007912.upk");
            Array.ForEach(w, File.Delete);
            //=====================================================
            string[] qb = Directory.GetFiles(GamePath.Text,
                "*00007913.upk");
            Array.ForEach(qb, File.Delete);
            //=====================================================
            string[] r = Directory.GetFiles(GamePath.Text,
                "*00007914.upk");
            Array.ForEach(r, File.Delete);
            //=====================================================
            string[] t = Directory.GetFiles(GamePath.Text,
                "*00007915.upk");
            Array.ForEach(t, File.Delete);
            //=====================================================
            string[] y = Directory.GetFiles(GamePath.Text,
                "*00007916.upk");
            Array.ForEach(y, File.Delete);
            //=====================================================
            string[] u = Directory.GetFiles(GamePath.Text,
                "*00007917.upk");
            Array.ForEach(u, File.Delete);
            //=====================================================
            string[] i = Directory.GetFiles(GamePath.Text,
                "*00018601.upk");
            Array.ForEach(i, File.Delete);
            //=====================================================
            string[] o = Directory.GetFiles(GamePath.Text,
                "*00023439.upk");
            Array.ForEach(o, File.Delete);
            //=====================================================
            string[] p = Directory.GetFiles(GamePath.Text,
                "*00034408.upk");
            Array.ForEach(p, File.Delete);
            //=====================================================
            string[] a = Directory.GetFiles(GamePath.Text,
                "*00056567.upk");
            Array.ForEach(a, File.Delete);
            //=====================================================
            string[] f = Directory.GetFiles(GamePath.Text,
                "*00056568.upk");
            Array.ForEach(f, File.Delete);
            //=====================================================
            string[] g = Directory.GetFiles(GamePath.Text,
                "*00056569.upk");
            Array.ForEach(g, File.Delete);
            //=====================================================
            string[] h = Directory.GetFiles(GamePath.Text,
                "*00056570.upk");
            Array.ForEach(h, File.Delete);
            //=====================================================
            string[] j = Directory.GetFiles(GamePath.Text,
                "*00056571.upk");
            Array.ForEach(j, File.Delete);
            //=====================================================
            string[] k = Directory.GetFiles(GamePath.Text,
                "*00056572.upk");
            Array.ForEach(k, File.Delete);
            //=====================================================
            string[] kq = Directory.GetFiles(GamePath.Text,
          "*00056573.upk");
            Array.ForEach(kq, File.Delete);
            //=====================================================
            string[] l = Directory.GetFiles(GamePath.Text,
                "*00056574.upk");
            Array.ForEach(l, File.Delete);
            //=====================================================
            string[] z = Directory.GetFiles(GamePath.Text,
                "*00056575.upk");
            Array.ForEach(z, File.Delete);
            //=====================================================
            string[] x = Directory.GetFiles(GamePath.Text,
                "*00056576.upk");
            Array.ForEach(x, File.Delete);
            //=====================================================
            string[] c = Directory.GetFiles(GamePath.Text,
                "*00056577.upk");
            Array.ForEach(c, File.Delete);
            //=====================================================
            string[] v = Directory.GetFiles(GamePath.Text,
                "*00060459.upk");
            Array.ForEach(v, File.Delete);
            //=====================================================
            string[] b = Directory.GetFiles(GamePath.Text,
                "*00060551.upk");
            Array.ForEach(b, File.Delete);
            //=====================================================
            string[] n = Directory.GetFiles(GamePath.Text,
                "*00064736.upk");
            Array.ForEach(n, File.Delete);
            //=====================================================
            string[] m = Directory.GetFiles(GamePath.Text,
                "*00064738.upk");
            Array.ForEach(m, File.Delete);
            //=====================================================
            string[] qw = Directory.GetFiles(GamePath.Text,
                "*00064820.upk");
            Array.ForEach(qw, File.Delete);
            //=====================================================
            string[] qe = Directory.GetFiles(GamePath.Text,
                "*00064821.upk");
            Array.ForEach(qe, File.Delete);
            //=====================================================
            string[] qr = Directory.GetFiles(GamePath.Text,
                "*00067307.upk");
            Array.ForEach(qr, File.Delete);
            //=====================================================
            string[] qt = Directory.GetFiles(GamePath.Text,
                "*00068166.upk");
            Array.ForEach(qt, File.Delete);
            //=====================================================
            string[] qy = Directory.GetFiles(GamePath.Text,
                "*00068516.upk");
            Array.ForEach(qy, File.Delete);
            //=====================================================
            string[] qu = Directory.GetFiles(GamePath.Text,
                "*00069254.upk");
            Array.ForEach(qu, File.Delete);
        }
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        } 
        private void RestoreButton_Click(object sender, EventArgs e) // восстановление анимаций
        {
            string dir1 = RecoveryPath.Text;
            string dir2 = GamePath.Text;
            try
            {
                DirectoryInfo dirInfo = new DirectoryInfo(dir1);
                foreach(FileInfo file in dirInfo.GetFiles("*.*"))
                {
                    File.Copy(file.FullName, dir2 + "\\" + file.Name, true);
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void button1_Click_1(object sender, EventArgs e) // Путь к анимациям в папке с игрой
        {
            using(var game = new FolderBrowserDialog())
            {
                if(game.ShowDialog() == DialogResult.OK && !string.IsNullOrWhiteSpace(game.SelectedPath))
                {
                    GamePath.Text = game.SelectedPath;
                }
            }
        }
        private void GamePath_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void button1_Click_2(object sender, EventArgs e) // Путь к резервной копии анимаций
        {
            using (var game = new FolderBrowserDialog())
            {
                if (game.ShowDialog() == DialogResult.OK && !string.IsNullOrWhiteSpace(game.SelectedPath))
                {
                    RecoveryPath.Text = game.SelectedPath;
                }
            }
        }
        private void RecoveryPath_TextChanged(object sender, EventArgs e)
        {
        }
    }
}
